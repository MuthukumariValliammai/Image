# Import libraries
import pandas as pd

# Load dataset
df = pd.read_csv("data.csv")

# Fix target column (if needed)
df['class'] = df['class'].str.replace("'", "").astype(int)

# Features & Target
X = df.drop("class", axis=1)
y = df["class"]

# Train-test split (IMPORTANT)
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Regression model
from sklearn.linear_model import LinearRegression
model = LinearRegression()

# Train
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Evaluation
from sklearn.metrics import mean_squared_error
print("MSE:", mean_squared_error(y_test, y_pred))