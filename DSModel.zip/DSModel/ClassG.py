# Classification.py

import pandas as pd

# Load dataset (works for both header/no header)
try:
    df = pd.read_csv("data2.csv")
    if 'class' not in df.columns:
        df = pd.read_csv("data.csv")
except:
    df = pd.read_csv("data2.csv")

# If no column names → assign
if df.columns.tolist() == list(range(len(df.columns))):
    cols = [f"f{i}" for i in range(df.shape[1]-1)] + ["target"]
    df.columns = cols

# Target = last column
target_col = df.columns[-1]

# Convert target if string
if df[target_col].dtype == 'object':
    from sklearn.preprocessing import LabelEncoder
    df[target_col] = LabelEncoder().fit_transform(df[target_col])

# Features & Target
X = df.drop(target_col, axis=1)
y = df[target_col]

# Split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Model
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Accuracy
from sklearn.metrics import accuracy_score
print("Accuracy:", accuracy_score(y_test, y_pred))