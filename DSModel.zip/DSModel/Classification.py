# Import libraries
import pandas as pd

# Load dataset
df = pd.read_csv("data2.csv")   # make sure file exists

# Fix target column (remove quotes if needed)
df['class'] = df['class'].str.replace("'", "").astype(int)

# Features & Target
X = df.drop("class", axis=1)   # your target is 'class'
y = df["class"]

# Train-test split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Model
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Prediction
y_pred = model.predict(X_test)

# Evaluation
from sklearn.metrics import accuracy_score
print("Accuracy:", accuracy_score(y_test, y_pred))