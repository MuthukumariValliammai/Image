# Import libraries
import pandas as pd

# Load dataset
df = pd.read_csv("data.csv")

# Fix target column (remove quotes)
df['class'] = df['class'].str.replace("'", "").astype(int)

# Drop target (unsupervised learning)
X = df.drop("class", axis=1)

# Apply KMeans
from sklearn.cluster import KMeans

kmeans = KMeans(n_clusters=3, random_state=0)
df['Cluster'] = kmeans.fit_predict(X)

# Print result
print(df[['Cluster']].head())

# Visualization (only first 2 features)
import matplotlib.pyplot as plt

plt.scatter(X.iloc[:, 0], X.iloc[:, 1], c=df['Cluster'])
plt.title("KMeans Clustering")
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.show()