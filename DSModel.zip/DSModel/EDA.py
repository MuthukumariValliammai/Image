# Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("data.csv")   # change file name

# Basic info
print(df.head())
print(df.info())
print(df.describe())

# Check missing values
print(df.isnull().sum())

# Handle missing values
df = df.dropna()   # or use fillna()

# Encoding categorical columns
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()

for col in df.select_dtypes(include=['object', 'string']):
    df[col] = le.fit_transform(df[col])

# Correlation heatmap
plt.figure(figsize=(8,6))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap")
plt.show()

# Distribution plot
df.hist(figsize=(10,8))
plt.show()

# Boxplot (outlier detection)
sns.boxplot(data=df)
plt.show()