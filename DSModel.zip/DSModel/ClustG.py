# Clustering.py

import pandas as pd

# Load dataset
df = pd.read_csv("data2.csv", header=None)

# Assign column names
cols = [f"f{i}" for i in range(df.shape[1])]
df.columns = cols

# Use all columns (unsupervised)
X = df.copy()

# KMeans
from sklearn.cluster import KMeans
kmeans = KMeans(n_clusters=3, random_state=0)

df['Cluster'] = kmeans.fit_predict(X)

# Output
print(df[['Cluster']].head())

# Cluster count
print("\nCluster Distribution:")
print(df['Cluster'].value_counts())

# Visualization (first 2 features)
import matplotlib.pyplot as plt
plt.scatter(X.iloc[:,0], X.iloc[:,1], c=df['Cluster'])
plt.title("Clustering")
plt.show()