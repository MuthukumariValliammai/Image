# Regression.py

import pandas as pd

# Load dataset
df = pd.read_csv("data2.csv", header=None)

# Assign column names
cols = [f"f{i}" for i in range(df.shape[1]-1)] + ["target"]
df.columns = cols

# Features & Target
X = df.drop("target", axis=1)
y = df["target"]

# Split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Model
from sklearn.linear_model import LinearRegression
model = LinearRegression()
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Evaluation
from sklearn.metrics import mean_squared_error
print("MSE:", mean_squared_error(y_test, y_pred))